<footer class="footer py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-4 text-lg-start">Copyright &copy; Delvia's Portfolio Website 2022</div>
            <div class="col-lg-4 my-3 my-lg-0">
                <a class="btn btn-dark btn-social mx-2" href="https://twitter.com/Delvia0765" aria-label="Delvia Lanasemba Twitter Profile"><i class="fab fa-twitter"></i></a>
                <a class="btn btn-dark btn-social mx-2" href="https://www.instagram.com/delvia_l/" aria-label="Delvia Lanasemba Facebook Profile"><i class="fab fa-instagram"></i></a>
                <a class="btn btn-dark btn-social mx-2" href="https://www.linkedin.com/in/delvia-lanasemba-716075156/" aria-label="Delvia Lanasemba LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a>
            </div>
            <div class="col-lg-4 text-lg-end">
                <a class="link-dark text-decoration-none me-3" href="#!">Privacy Policy</a>
                <a class="link-dark text-decoration-none" href="#!">Terms of Use</a>
            </div>
        </div>
    </div>
</footer>