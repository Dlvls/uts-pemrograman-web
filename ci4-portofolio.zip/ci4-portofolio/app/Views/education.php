<section class="page-section" id="about">
    <div class="container">
        <div class="text-center">
            <h2 class="section-heading text-uppercase">Education</h2>
            <h3 class="section-subheading text-muted">Education undertaken</h3>
        </div>
        <?php foreach ($edu as $k) : ?>
            <ul class="timeline">
                <li class="timeline-inverted">
                    <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/<?= $k["edu_img"]; ?>" alt="..." /></div>
                    <div class="timeline-panel">
                        <div class="timeline-heading">
                            <h4><?= $k["edu_name"]; ?></h4>
                            <h4 class="subheading">Attended School From <?= $k["edu_in"]; ?>-<?= $k["edu_out"]; ?></h4>
                        </div>
                        <div class="timeline-body">
                            <p class="text-muted">Alamat: <?= $k["edu_address"]; ?></p>
                        </div>
                    </div>
                </li>
                <!-- <li class="timeline-inverted">
                <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/smp-2.png" alt="..." /></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4 class="subheading">SMP Negeri 1 Sukaraja</h4>
                        <h4>Attended School From 2013-2016</h4>
                    </div>
                    <div class="timeline-body">
                        <p class="text-muted">Alamat: Jl. Siliwangi No.65, Pasirhalang, Kec. Sukaraja, Kabupaten Sukabumi, Jawa Barat 43192</p>
                        <a class="text-muted" href="https://www.smpn1sukaraja.sch.id/" aria-label="SMP Negeri 1 Sukaraja">Website SMP Negeri 1 Sukaraja</a>
                    </div>
                </div>
            </li>
            <li>
                <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/smp-2.png" alt="..." /></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4>SMA Negeri 1 Sukaraja</h4>
                        <h4 class="subheading">Attended School From 2016-2019</h4>
                    </div>
                    <div class="timeline-body">
                        <p class="text-muted">Major in Natural Science</p>
                        <p class="text-muted">Alamat: Jl. MH. HOLIL Jl. MH. Holil No.261/78, Sukaraja, Sukabumi Regency, West Java 43192</p>
                        <a class="text-muted" href="http://sman1sukarajasmi.sch.id/html/index.php" aria-label="SMA Negeri 1 Sukaraja">Website SMA Negeri 1 Sukaraja</a>
                    </div>
                </div>
            </li>
            <li class="timeline-inverted">
                <div class="timeline-image"><img class="rounded-circle img-fluid" src="assets/img/about/ummi.png" alt="..." /></div>
                <div class="timeline-panel">
                    <div class="timeline-heading">
                        <h4>Muhammadiyah University of Sukabumi</h4>
                        <h4 class="subheading">Expected to Graduate on 2024</h4>
                    </div>
                    <div class="timeline-body">
                        <p class="text-muted">Major in Informatics Engineering</p>
                        <p class="text-muted">Alamat: Jl. R. Syamsudin, S.H. No. 50, Cikole, Kec. Cikole, Kota Sukabumi, Jawa Barat 43113</p>
                        <a class="text-muted" href="https://ummi.ac.id/" aria-label="Universitas Muhammadiyah Sukabumi">Website Universitas Muhammadiyah Sukabumi</a>
                    </div>
                </div>
            </li> -->
            </ul>
        <?php endforeach; ?>
    </div>
</section>