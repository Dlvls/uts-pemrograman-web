    <!-- Team-->
    <section class="page-section bg-light" id="team">
        <div class="container">
            <div class="text-center">
                <h2 class="section-heading text-uppercase">I'm Delvia Lanasemba</h2>
                <h3 class="section-subheading text-muted">Muhammadiyah University of Sukabumi</h3>
            </div>
            <div class="row">
                <div class="col-lg-8 mx-auto text-center">
                    <img class="mx-auto rounded-circle" src="assets/img/team/grey-banget.png" alt="..." />
                    <p class="text-muted">Colleger</p>
                    <p class="text-muted">Major in Informatics Engineering</p>
                    <p class="text-muted">Cumulative GPA: 3.80/4.0</p>
                    <p class="large text-muted">I am a hard working, consistent individual. I am dedicated and always willing to learn new skills. I am able to keep myself calm in a busy environment. I am outgoing, polite, and responsible person. I am able to take instructions and have a good working relationship with all colleagues. I am flexible and good at prioritizing.</p>
                    <a class="btn btn-dark btn-social mx-2" href="https://twitter.com/Delvia0765" aria-label="Delvia Lanasemba Twitter Profile"><i class="fab fa-twitter"></i></a>
                    <a class="btn btn-dark btn-social mx-2" href="https://www.instagram.com/delvia_l/" aria-label="Delvia Lanasemba Facebook Profile"><i class="fab fa-instagram"></i></a>
                    <a class="btn btn-dark btn-social mx-2" href="https://www.linkedin.com/in/delvia-lanasemba-716075156/" aria-label="Delvia Lanasemba LinkedIn Profile"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>
    </section>