<?php

namespace App\Controllers;

use App\Models\PortoModel;

class Home extends BaseController
{
    protected $PortoModel;
    public function __construct()
    {
        $this->PortoModel = new PortoModel();
    }

    public function index()
    {
        $edu = $this->PortoModel->findAll();
        $data = [
            'edu' => $edu
        ];

        return view('index', $data);
    }
}
